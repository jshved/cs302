To compile, type "make" inside of terminal. To run the program, use ./solution < <sequencefile.txt>
